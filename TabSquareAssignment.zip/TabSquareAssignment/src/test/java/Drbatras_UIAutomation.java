import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

public class Drbatras_UIAutomation {
    public static void main(String[] args) throws InterruptedException, IOException {
        //WebDriverManager.chromedriver().setup();
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\904475\\chromedriver\\chromedriver_win32 (7)\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.setBinary("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
        WebDriver driver = new ChromeDriver(options);
        driver.get("https://www.drbatras.com/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        //Hover on treatments
        driver.manage().deleteAllCookies();
        WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='collapse navbar-collapse float-md-right menu_right']//following::ul/li[1]/a[@id='navbarDropdown0']")));
        WebElement ele = driver.findElement(By.xpath("//a[@id='navbarDropdown0']"));
        Actions action = new Actions(driver);
        action.moveToElement(ele).perform();
        //Click child health
        driver.findElement(By.linkText("Child Health")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.findElement(By.xpath("//div[@class='sub-menu-undersub-child-menu1 conditions1 menu-tab-content']//following::ul/li/a[@title='Immunity']")).click();
        System.out.println("Reached here");

        //Click on chat window
         wait=new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[contains(text(),'Hello There \uD83D\uDC4B, chat with us!')]")));
        driver.findElement(By.xpath("//p[contains(text(),'Hello There \uD83D\uDC4B, chat with us!')]")).click();
        //close the chat window
        driver.switchTo().frame("kenytChatWindow");
        driver.findElement(By.xpath("//*[@id='headerCloseButton']/span")).click();
        driver.switchTo().defaultContent();
        //click on consult now
        driver.findElement(By.xpath("//a[contains(text(),'CONSULT NOW')]")).click();
        //Entering details

        driver.findElement(By.xpath("//input[@id='request_name']")).sendKeys("Arunadevi K");
        driver.findElement(By.xpath("//input[@id='request_contact_no']")).sendKeys("8973237441");
        driver.findElement(By.xpath("//input[@id='request_email']")).sendKeys("arunadevi.arun28@gmail.com");
        driver.findElement(By.xpath("//input[@id='terms_and_conditions_chk']")).click();
        driver.findElement(By.xpath("//div[@class='col-12']//following::button[contains(text(),'NEXT')]")).click();

        //confirm your apponitment button
       Thread.sleep(5000);
        WebElement btn=driver.findElement(By.xpath("//button[@id='book-an-appointment-sectwo']"));
        System.out.println("done");
        if(btn.isDisplayed())
        {
            System.out.println("Confirm Your Appointment button is Visible on the page");
        }

        //Screenshot of last page
        WebElement screen=driver.findElement(By.xpath("//body/div[1]/div[1]/div[5]/div[1]/main[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]"));
        File src=screen.getScreenshotAs(OutputType.FILE);
        Date d = new Date();
        String FileName = d.toString().replace(":", "_").replace(" ", "_") + ".png";
        File target=new File("ConfirmYourAppointmentPage_"+ FileName);
        FileUtils.copyFile(src,target);

        driver.close();
    }
}
