
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

public class Scenerio2_UIAutomation {
    public static void main(String[] args) throws InterruptedException, IOException {
//WebDriverManager.chromedriver().setup();
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\904475\\chromedriver\\chromedriver_win32 (7)\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.setBinary("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
        WebDriver driver = new ChromeDriver(options);
        driver.get("https://smartweb-ecms.tabsquare.com/scan/ac74085b-8afd-4475-91f1-f4e8ba642dce");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        //Choosing country code from dropdown
        WebElement dropdown=driver.findElement(By.xpath("//select[@name='country_code']"));
        Select s=new Select(dropdown);
        s.selectByVisibleText("+91 (India)");
        //Passing Mobile number
        driver.findElement(By.xpath("//input[@name='mobile_no']")).sendKeys("8973237441");
        driver.findElement(By.xpath("//button[@class='btn-login btn-primary']")).click();

        driver.findElement(By.xpath("//a[@data-text='Dine In']")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//div[@class='item-text']//following::a[3]")).click();
        driver.findElement(By.xpath("//div[@class='wrap-button no-req']//following::a[@class='add-btn add-sku-btn btn-primary']")).click();
        driver.findElement(By.xpath("//a[@id='checkoutButton']")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.findElement(By.xpath("//ul[@class='add-action']//following::a[@class='to-plus btn-primary']")).click();
        WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='add-action']//following::a[@class='to-plus btn-primary']")));
        driver.findElement(By.xpath("//ul[@class='add-action']//following::a[@class='to-plus btn-primary']")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.findElement(By.xpath("//body/div[1]/div[25]/div[2]/ul[1]/li[5]/ul[1]/li[3]/a[1]")).click();
        Thread.sleep(10000);
        WebElement Ordermsg=driver.findElement(By.xpath("//div[@class='subtit-invoice order-sent']//following::p"));
        if(Ordermsg.isDisplayed())
        {
            System.out.println("Order has been successfully placed");
        }

        WebElement orderid=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/span[1]"));
        String OrderID=orderid.getText();
        System.out.println("Order ID:" + OrderID);

        //Taking screenshot of the Order section
        WebElement ordersection=driver.findElement(By.xpath("//body/div[3]/div[1]/section[1]/div[5]"));
        File src=ordersection.getScreenshotAs(OutputType.FILE);
        Date d = new Date();
        String FileName = d.toString().replace(":", "_").replace(" ", "_") + ".png";
        File target=new File("OrderIDScreenshot_"+ FileName);
        FileUtils.copyFile(src,target);
        driver.close();


    }

}
