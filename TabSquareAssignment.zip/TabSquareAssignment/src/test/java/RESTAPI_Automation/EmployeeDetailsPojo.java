package RESTAPI_Automation;

import java.util.List;

public class EmployeeDetailsPojo {
    private List<String> firstanme;
    private List<String> lastname;
    private List<String> DOB;

    public List<String> getFirstanme() {
        return firstanme;
    }

    public void setFirstanme(List<String> firstanme) {
        this.firstanme = firstanme;
    }

    public List<String> getLastname() {
        return lastname;
    }

    public void setLastname(List<String> lastname) {
        this.lastname = lastname;
    }

    public List<String> getDOB() {
        return DOB;
    }

    public void setDOB(List<String> DOB) {
        this.DOB = DOB;
    }
}
