package RESTAPI_Automation;

public class GetterSettersPojo {
    private String company;
    private String address;
    private EmployeeDetailsPojo employeeDetails;

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public EmployeeDetailsPojo getEmployeeDetails() {
        return employeeDetails;
    }

    public void setEmployeeDetails(EmployeeDetailsPojo employeeDetails) {
        this.employeeDetails = employeeDetails;
    }
}
