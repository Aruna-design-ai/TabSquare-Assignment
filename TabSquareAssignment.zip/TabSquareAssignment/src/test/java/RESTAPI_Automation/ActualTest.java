package RESTAPI_Automation;

import com.aventstack.extentreports.util.Assert;
import io.restassured.RestAssured;

import java.util.ArrayList;

import static io.restassured.RestAssured.get;

public class ActualTest {
    public static void main(String[] args)
    {
        RestAssured.baseURI="https://qvi7e.mocklab.io/tabsquare/employee/details";
        // creating Json file to work with GET method
        GetterSettersPojo ap=new GetterSettersPojo();
        ap.setCompany("TabSquare");
        ap.setAddress("Singapore");
        EmployeeDetailsPojo ep=new EmployeeDetailsPojo();
        ArrayList<String> firstnames=new ArrayList<>();
        firstnames.add("Budi");
        firstnames.add("susi");
        ep.setFirstanme(firstnames);
        ArrayList<String> Lastnames=new ArrayList<>();
        Lastnames.add("Cahya");
        Lastnames.add("Kya");
        ep.setLastname(Lastnames);
        ArrayList<String> dobs=new ArrayList<>();
        dobs.add("221150");
        dobs.add("512300");
        ep.setDOB(dobs);



        ap=get("https://qvi7e.mocklab.io/tabsquare/employee/details").as(GetterSettersPojo.class);
            System.out.println("Address:" + ap.getAddress());
            System.out.println("Employee Details:" + ap.getEmployeeDetails());
        }




}
